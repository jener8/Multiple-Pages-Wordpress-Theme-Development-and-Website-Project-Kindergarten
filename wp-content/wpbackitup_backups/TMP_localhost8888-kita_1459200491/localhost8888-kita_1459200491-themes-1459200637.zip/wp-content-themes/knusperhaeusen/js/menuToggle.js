jQuery( document ).ready(function( $ ) {


var
nav = $(".navbar ");
hm = "hidenone";
pg = $(".pgwrapper")
pp1 = "pgpadding1";
pp2 = "pgpadding2";


if ($(window).width() < 768) {
$("#menu-button").click(function() {

           if (!(nav).hasClass(hm)) {
               nav.addClass(hm);
               pg.removeClass(pp1)
               pg.addClass(pp2);
              } else {
                  nav.removeClass(hm);
                  pg.removeClass(pp2);
                  pg.addClass(pp1);
                      }

});
}


//refresh page on browser resize
$(window).bind('resize', function(e)
               {
    if (window.RT) clearTimeout(window.RT);
    window.RT = setTimeout(function()
                           {
        this.location.reload(false); /* false to get page from cache */
    }, 200);
});






});

