
jQuery( document ).ready(function( $ ) {


var


    m1 = $(".menu1");
me = $(".main-entry");
mm = $(".main-menu");
mn = $(".main-nav");
menu = $(".menu-icon");
logo = $("#logomain");
mns = "main-nav-scrolled";
btm = "bottom-stay";
button = $(".button");
ts = "top-stay";

hdr = $('.main-nav').offset().top;




$(document).ready(function() {





//scrolling


    if ($(window).width() < 375) {
        me.css("display", "none");
    } else {
//        me.css("display", "initial");


    if ($(window).width() < 768) {
        mn.addClass(mns);
        mm.addClass(mns);

        mn.removeClass(btm);

        button.css("display", "none");
        menu.css("display", "inline");
        mm.css("display", "initial");
        me.css("display", "none");
        logo.css("display", "none");

    }else{

        mn.removeClass(mns);
        mn.addClass(btm);
        logo.css("display", "inline");
        menu.css("display", "none");
        button.css("display", "initial");
        mm.css("display", "none");

    }
    }
});

$(window).scroll(function() {

    if ($(window).width() >= 768) {

        if ($(this).scrollTop() > hdr) {
            mn.addClass(mns);
            mm.addClass(mns);

            mn.removeClass(btm);

            button.css("display", "none");
            menu.css("display", "inline");
            mm.css("display", "initial");
//            me.css("display", "none");
            logo.css("display", "none");

          $(me).find('br').remove();
          me.css({"display": "initial","left": "0", "right": "0", "margin": "0 auto","text-align": "center","top": "200%","font-size": "1.3em", "color":"darkorange"});

        } else {

          if ($(window).width() > 800) {
            me.css("font-size", "1.8em");
          }


          if ($(window).width() < 375) {
            me.css("display", "none");
          }

//
//            mn.removeClass(mns);
//            mn.addClass(btm);
//            logo.css("display", "inline");
//            menu.css("display", "none");
//            button.css("display", "initial");
//            mm.css("display", "none");


        }
    }


});



});









